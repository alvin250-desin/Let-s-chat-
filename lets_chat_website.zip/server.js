
const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'client/build'))); // Serve React app

// Replace with your MoMo API credentials
const apiUser = 'YOUR_API_USER'; // From the MTN MoMo portal
const apiKey = 'YOUR_API_KEY';   // From the MTN MoMo portal
const subscriptionKey = 'YOUR_SUBSCRIPTION_KEY';
const callbackUrl = 'https://yourwebsite.com/callback'; // Replace with your callback URL

// Generate an access token
const getAccessToken = async () => {
  const response = await axios.post('https://sandbox.momodeveloper.mtn.com/collection/token/', {}, {
    headers: {
      Authorization: `Basic ${Buffer.from(`${apiUser}:${apiKey}`).toString('base64')}`,
    },
  });
  return response.data.access_token;
};

// Handle payment
app.post('/pay', async (req, res) => {
  const { amount, phone } = req.body;

  try {
    const accessToken = await getAccessToken();

    const response = await axios.post(
      'https://sandbox.momodeveloper.mtn.com/collection/v1_0/requesttopay',
      {
        amount: amount.toString(),
        currency: 'RWF',
        externalId: '123456',
        payer: {
          partyIdType: 'MSISDN',
          partyId: phone,
        },
        payerMessage: 'Payment for Let's Chat',
        payeeNote: 'Subscription Payment',
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'X-Reference-Id': 'YOUR_UNIQUE_TRANSACTION_ID',
          'X-Target-Environment': 'sandbox',
          'Ocp-Apim-Subscription-Key': subscriptionKey,
        },
      }
    );

    res.json({ success: true, message: 'Payment initiated successfully', data: response.data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Payment failed', error: error.message });
  }
});

// Serve React app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
});

app.listen(3000, () => console.log('Server running on port 3000'));
