
import React from 'react';
import PaymentForm from './PaymentForm';

function App() {
  return <PaymentForm />;
}

export default App;
